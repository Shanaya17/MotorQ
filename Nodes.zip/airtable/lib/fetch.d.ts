declare const _default: any;
export = _default;
