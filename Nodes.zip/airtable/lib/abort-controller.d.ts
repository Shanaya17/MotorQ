declare let AbortController: new () => AbortController;
export = AbortController;
