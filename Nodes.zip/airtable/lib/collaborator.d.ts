export interface Collaborator {
    id: string;
    email: string;
    name: string;
}
