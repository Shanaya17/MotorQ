export interface Thumbnail {
    url: string;
    width: number;
    height: number;
}
