declare const _default: string;
export = _default;
