declare type ToParamBody = any;
declare function objectToQueryParamString(obj: ToParamBody): string;
export = objectToQueryParamString;
