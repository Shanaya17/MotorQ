declare function exponentialBackoffWithJitter(numberOfRetries: number): number;
export = exponentialBackoffWithJitter;
